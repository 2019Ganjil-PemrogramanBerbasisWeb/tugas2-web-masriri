<?php
mysql_connect("localhost","root",""); //sesuaikan dengan password dan username mysql anda
mysql_select_db("sampah_overview"); //nama database yang kita gunakan
?>
